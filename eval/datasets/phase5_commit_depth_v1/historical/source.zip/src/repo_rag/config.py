"""Application settings. All env vars and tunable defaults live here."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Loaded from environment variables and `.env`.

    Tunables use the `REPO_RAG_` prefix (e.g. `REPO_RAG_MAX_CHUNK_CHARS`).
    API keys use their conventional unprefixed names.
    """

    model_config = SettingsConfigDict(
        env_prefix="REPO_RAG_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    # --- Secrets ---
    anthropic_api_key: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("ANTHROPIC_API_KEY", "anthropic_api_key")
    )
    github_token: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("GITHUB_TOKEN", "github_token")
    )
    voyage_api_key: SecretStr | None = Field(
        default=None, validation_alias=AliasChoices("VOYAGE_API_KEY", "voyage_api_key")
    )

    # --- Storage ---
    data_dir: Path = Path("data")

    # --- Models ---
    llm_provider: Literal["local"] = "local"
    llm_model: str | None = None
    summary_model: str | None = None
    """Phase 7 will select and measure an open-source answer model; no paid key required."""
    # Chosen by eval/embedding_bench (see eval/RESULTS.md). Qwen3-Embedding-0.6B led the
    # developer-question task by a wide margin and is Apache-2.0 and laptop-viable.
    embedding_provider: Literal["voyage", "huggingface"] = "huggingface"
    embedding_model: str = "voyage-code-3"
    """Used when embedding_provider == "voyage" (untested paid option)."""
    local_embedding_model: str = "Qwen/Qwen3-Embedding-0.6B"
    embedding_dims: int | None = Field(default=512, gt=0)
    """Matryoshka truncation. 512 matched full 1024 dims on our eval at half the index size.
    None keeps the model's full dimension."""
    embedding_query_instruction: str = (
        "Instruct: Given a developer question or a description of behaviour, "
        "retrieve the code that implements it\nQuery:"
    )
    """Qwen3 query instruction, used for every collection (code, docs, commits). T3 tuning found
    no commit-specific instruction that beat it (eval/RESULTS.md). Documents get no prompt."""
    embedding_max_tokens: int = Field(default=2048, gt=0)
    """Per-chunk token cap, the same one the embedding benchmark used."""
    embedding_batch_size: int = Field(default=16, gt=0)
    compute_device: Literal["auto", "cpu", "cuda"] = "auto"
    embedding_dtype: Literal["auto", "float32", "bfloat16"] = "auto"
    """auto = bfloat16 on a GPU, float32 on a CPU. Index vectors built on a GPU and queries
    embedded on a laptop CPU should use the same dtype: set float32 when building elsewhere."""
    commit_diff_chars: int = Field(default=800, gt=0)
    """Commit docs = message + files + touched symbols + this much diff. 800 matched 2,000 on
    bug -> fix retrieval and indexes about 1.4x faster."""
    reranker_model: str = "Qwen/Qwen3-Reranker-8B"
    """The 8B judge beat the 4B on code questions: MRR@10 0.860 -> 0.926 over 150 questions
    (eval/RESULTS.md, Phase 4 judge run), at about +45% rerank latency. Bug -> fix reranking was
    measured only with the 4B (nDCG@10 0.494 -> 0.687 over the top 50); re-measure it with the 8B in
    Phase 5. bge-reranker-v2-m3 made bug -> fix worse (-0.12)."""
    reranker_mode: Literal["auto", "on", "off"] = "auto"
    """auto = rerank only when a CUDA GPU is available. On a laptop CPU even the 0.6B reranker
    took ~23 s for 5 candidates; the 4B took ~1.8 s per query (top 50) on an A100, the 8B is
    about 1.4x slower."""
    rerank_instruction: str = (
        "Given a bug report, judge whether this commit's changes fix the reported bug"
    )
    code_rerank_instruction: str = (
        "Given a developer question, retrieve the code that implements the requested behaviour"
    )
    docs_rerank_instruction: str = (
        "Given a developer question, retrieve documentation that answers the question"
    )
    rerank_instruction_mode: Literal["default", "intent", "source_aware"] = "default"
    """Which task instruction code reranking uses. `intent` switches on a keyword detector for
    'implementation'/'test' wording; `source_aware` sends every code query one instruction that
    prefers source over tests unless the question asks for a test or example. GPU policy run:
    `intent` gained only on the template wording it was written from (+0.167 on 12 such
    questions, +0.000 on the 30 paraphrases); `source_aware` +0.007 MRR, CI [-0.015, +0.033].
    Neither is reliable, so both stay off."""
    code_rerank_instruction_implementation: str = (
        "Given a developer question asking where behaviour is implemented, retrieve the source "
        "code that implements it, not tests or examples that only demonstrate it"
    )
    code_rerank_instruction_test: str = (
        "Given a developer question asking which test checks a behaviour, retrieve the test "
        "that verifies it, not the implementation"
    )
    code_rerank_instruction_source_aware: str = (
        "Given a developer question, retrieve the code that implements the requested behaviour; "
        "prefer source code over tests and examples unless the question asks for a test or example"
    )
    rerank_first_stage_weight: float = Field(default=0.0, ge=0)
    """Code reranking only. 0 orders by the reranker's P(yes). A positive weight orders by
    log-odds of P(yes) plus this weight times -ln(first-stage rank). Offline on saved scores,
    0.25 looked slightly better; the live GPU policy run did not confirm it (MRR +0.006 over
    120 questions, CI [-0.013, +0.026]; test questions -0.028), so it stays off."""
    rerank_max_tokens: int = Field(default=2048, gt=0)

    # --- Ingestion ---
    max_file_bytes: int = Field(default=1_000_000, gt=0)
    max_commits: int = Field(default=5000, gt=0)
    commit_patch_chars: int = Field(default=100_000, gt=0)
    """Per-file patch retained in history records; document diff uses commit_diff_chars."""
    github_timeout_seconds: float = Field(default=30, gt=0)

    # --- Chunking ---
    max_chunk_chars: int = Field(default=1500, gt=0)
    """Chunk size budget in non-whitespace characters (cAST convention)."""
    header_defines: bool = False
    """Add a `# defines: a, b, c` header line to chunks that merge several definitions. Phase 4
    found such chunks described only by an unrelated first name. OFF until a GPU run shows it
    helps: BM25-only on the 120 policy cases it was neutral to slightly negative (MRR 0.478 ->
    0.472; ambiguous 0.489 -> 0.451). Changing it changes chunk text, so re-index."""
    header_max_defines_chars: int = Field(default=240, gt=0)
    """Longest `# defines:` list, in characters; longer lists end in `...`."""
    ast_max_error_ratio: float = Field(default=0.1, ge=0, le=1)
    """Fall back to the text splitter when more than this share of a file's bytes sits in
    tree-sitter ERROR/MISSING nodes. Small errors are tolerated; tree-sitter recovers well."""
    fallback_chunk_overlap: int = Field(default=100, ge=0)
    """Character overlap for fallback (non-AST) chunks. AST chunks never overlap."""

    # --- Retrieval ---
    retrieval_k: int = Field(default=50, gt=0)
    """Candidates per first-stage signal. Recall@50 on bug -> fix: 0.86."""
    rerank_candidate_depth: int = Field(default=50, gt=0)
    """Maximum fused candidates scored when reranking is requested; independent of retrieval_k.
    Keep the previous 50-candidate behaviour by default; 20 is an explicit experiment."""
    rerank_top_n: int = Field(default=8, gt=0)
    evidence_expansion: Literal["none", "adjacent", "callee", "both"] = "none"
    """Experimental additions after reranked code search only; never on the CPU/hybrid path.
    Name matching is not a call graph. Default remains off pending the frozen expansion eval."""
    expansion_keep: int = Field(default=5, ge=1)
    expansion_seeds: int = Field(default=3, ge=1)
    expansion_per_seed: int = Field(default=2, ge=1)
    expansion_max_definers: int = Field(default=3, ge=1)
    dense_weight: float = Field(default=1.0, ge=0)
    bm25_weight: float = Field(default=0.3, ge=0)
    """PROVISIONAL. Fusion is weighted RRF. Equal weights measurably hurt Qwen3 in the embedding
    benchmark (mean nDCG@10 0.612 -> 0.585), so BM25 gets a smaller vote. 0.3 is a guess that
    has not been established as a universal optimum by Phase 4."""
    rrf_k: int = Field(default=60, gt=0)

    # --- Evaluation (never changes production retrieval defaults) ---
    eval_char_overlap: int = Field(default=200, ge=0)
    eval_cutoffs: tuple[int, ...] = (1, 5, 10)
    eval_bm25_weights: tuple[float, ...] = (0.0, 0.1, 0.3, 0.5, 1.0)
    eval_test_penalties: tuple[float, ...] = (1.0, 0.8)
    eval_rerank_depths: tuple[int, ...] = (20, 50)
    eval_code_instruction: str = (
        "Given a developer question, retrieve the code that implements the requested behaviour"
    )
    eval_split_seed: int = 42
    eval_dev_fraction: float = Field(default=0.4, gt=0, lt=1)
    eval_coverage_threshold: float = Field(default=0.9, gt=0, le=1)
    eval_bootstrap_samples: int = Field(default=10000, ge=100)
    eval_bootstrap_confidence: float = Field(default=0.95, gt=0, lt=1)
    eval_bootstrap_seed: int = 42
    eval_followup_candidate_depth: int = Field(default=20, gt=0)
    eval_followup_bm25_quota: int = Field(default=5, ge=0)
    eval_followup_latency_repeats: int = Field(default=3, gt=0)
    eval_followup_trace_ids: tuple[str, ...] = (
        "requests-036",
        "requests-028",
        "express-036",
        "express-028",
    )

    # --- Chroma ---
    chroma_sync_threshold: int = Field(default=2, ge=2)
    """Chroma writes its vector index to disk after this many unflushed writes. Its default
    (1000) keeps new vectors only in memory, and a read in that window intermittently fails with
    "Error creating hnsw segment reader: Nothing found on disk". Reproduced with raw chromadb:
    20 failures in 5,760 reads at the default, 0 at 2. Cost: none measurable (2,000 x 512-d
    vectors written in 1.2 s instead of 1.0 s)."""

    @property
    def clones_dir(self) -> Path:
        return self.data_dir / "repos"

    @property
    def chroma_dir(self) -> Path:
        return self.data_dir / "chroma"

    @property
    def bm25_dir(self) -> Path:
        return self.data_dir / "bm25"

    @property
    def manifest_path(self) -> Path:
        return self.data_dir / "manifest.json"

    @property
    def metadata_db_path(self) -> Path:
        return self.data_dir / "metadata.db"

    @property
    def github_cache_dir(self) -> Path:
        return self.data_dir / "github_cache"

    @property
    def embedding_id(self) -> str:
        """Identifies the embedding space; vectors from different ids must never be mixed."""
        model = self.local_embedding_model.split("/")[-1]
        return f"{model}_{self.embedding_dims or 'full'}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
