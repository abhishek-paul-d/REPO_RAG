"""Chroma-backed chunk store (via langchain-chroma), one collection per kind.

Collections are named after the embedding space (`code_chunks__Qwen3-Embedding-0.6B_512`), so
vectors from different models or dimensions can never be mixed. Every collection holds many
repos, told apart by the `repo` metadata field that all queries filter on.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import chromadb
import numpy as np
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from repo_rag.config import Settings, get_settings

COLLECTIONS = {"code": "code_chunks", "docs": "docs"}
# File indexing/legacy transfers still iterate COLLECTIONS. History has its own snapshot.
SEARCH_COLLECTIONS = {**COLLECTIONS, "commits": "commits"}
_UNSAFE_NAME_CHARS = re.compile(r"[^A-Za-z0-9._-]")


@dataclass
class SyncStats:
    added: int = 0
    updated: int = 0  # text changed, so re-embedded
    metadata_only: int = 0  # same text, new metadata (e.g. a new commit sha); not re-embedded
    unchanged: int = 0
    removed: int = 0

    @property
    def embedded(self) -> int:
        return self.added + self.updated


def build_where(repo: str, filters: Mapping[str, str] | None = None) -> dict[str, Any]:
    """A Chroma `where` clause: always the repo, plus exact-match metadata filters."""
    clauses: list[dict[str, Any]] = [{"repo": repo}]
    clauses += [{key: value} for key, value in (filters or {}).items() if value]
    return clauses[0] if len(clauses) == 1 else {"$and": clauses}


class VectorStore:
    def __init__(
        self,
        settings: Settings | None = None,
        embeddings: Embeddings | None = None,
        client: chromadb.ClientAPI | None = None,
    ) -> None:
        self.settings = settings or get_settings()
        if embeddings is None:
            from repo_rag.store.embeddings import get_embeddings

            embeddings = get_embeddings(self.settings)
        self.embeddings = embeddings
        self._client = client
        self._stores: dict[str, Chroma] = {}

    # ---------------------------------------------------------------- collections

    def collection_name(self, kind: str) -> str:
        suffix = _UNSAFE_NAME_CHARS.sub("-", self.settings.embedding_id)
        return f"{SEARCH_COLLECTIONS[kind]}__{suffix}"

    @property
    def client(self) -> chromadb.ClientAPI:
        if self._client is None:
            self.settings.chroma_dir.mkdir(parents=True, exist_ok=True)
            self._client = chromadb.PersistentClient(path=str(self.settings.chroma_dir))
        return self._client

    def _read(self, kind: str, **kwargs: Any) -> dict[str, Any]:
        return self._store(kind).get(**kwargs)

    def _store(self, kind: str) -> Chroma:
        if kind not in self._stores:
            threshold = self.settings.chroma_sync_threshold
            store = Chroma(
                collection_name=self.collection_name(kind),
                embedding_function=self.embeddings,
                client=self.client,
                collection_configuration={"hnsw": {"space": "cosine", "sync_threshold": threshold}},
            )
            # Collections made before this setting existed keep Chroma's lazy default (1000):
            # switch them too, so every read can find the vector index on disk.
            store._collection.modify(configuration={"hnsw": {"sync_threshold": threshold}})
            self._stores[kind] = store
        return self._stores[kind]

    # ---------------------------------------------------------------- writing

    def sync(
        self,
        kind: str,
        repo: str,
        docs: Sequence[Document],
        *,
        force: bool = False,
        batch_size: int = 64,
        on_progress: Callable[[int, int], None] | None = None,
    ) -> SyncStats:
        """Make the repo's chunks in this collection equal `docs`, embedding only what changed.

        Unchanged chunks are neither re-embedded nor rewritten. Chunks no longer produced are
        deleted. Safe to run repeatedly.
        """
        store = self._store(kind)
        by_id: dict[str, Document] = {}
        for doc in docs:
            by_id[str(doc.metadata["chunk_id"])] = doc  # ids are unique by construction

        existing = self._read(kind, where=build_where(repo), include=["documents", "metadatas"])
        old_text = dict(zip(existing["ids"], existing["documents"], strict=True))
        old_meta = dict(zip(existing["ids"], existing["metadatas"], strict=True))

        stats = SyncStats()
        to_embed: list[str] = []
        meta_only: list[str] = []
        for chunk_id, doc in by_id.items():
            if chunk_id not in old_text:
                to_embed.append(chunk_id)
                stats.added += 1
            elif force or old_text[chunk_id] != doc.page_content:
                to_embed.append(chunk_id)
                stats.updated += 1
            elif old_meta[chunk_id] != doc.metadata:
                meta_only.append(chunk_id)
                stats.metadata_only += 1
            else:
                stats.unchanged += 1

        stale = [chunk_id for chunk_id in old_text if chunk_id not in by_id]
        if stale:
            store.delete(ids=stale)
            stats.removed = len(stale)
        if meta_only:
            store._collection.update(
                ids=meta_only, metadatas=[by_id[i].metadata for i in meta_only]
            )

        for start in range(0, len(to_embed), batch_size):
            batch = to_embed[start : start + batch_size]
            store.add_texts(
                [by_id[i].page_content for i in batch],
                metadatas=[by_id[i].metadata for i in batch],
                ids=batch,
            )
            if on_progress:
                on_progress(min(start + batch_size, len(to_embed)), len(to_embed))
        return stats

    def export_records(
        self, kind: str, repo: str
    ) -> tuple[list[str], list[str], list[dict[str, Any]], np.ndarray]:
        """Everything stored for a repo, sorted by id: (ids, texts, metadatas, vectors)."""
        got = self._read(
            kind, where=build_where(repo), include=["documents", "metadatas", "embeddings"]
        )
        order = sorted(range(len(got["ids"])), key=lambda i: got["ids"][i])
        ids = [got["ids"][i] for i in order]
        texts = [got["documents"][i] for i in order]
        metas = [dict(got["metadatas"][i]) for i in order]
        vectors = np.asarray([got["embeddings"][i] for i in order], dtype=np.float32)
        return ids, texts, metas, vectors

    def replace_records(
        self,
        kind: str,
        repo: str,
        ids: Sequence[str],
        texts: Sequence[str],
        metas: Sequence[Mapping[str, Any]],
        vectors: np.ndarray,
        *,
        batch_size: int = 512,
    ) -> int:
        """Make the repo's chunks exactly these records, using the given vectors as they are
        (nothing is re-embedded). Returns how many stale chunks were deleted."""
        store = self._store(kind)
        keep = set(ids)
        current = self._read(kind, where=build_where(repo), include=[])["ids"]
        stale = [i for i in current if i not in keep]
        if stale:
            store.delete(ids=stale)
        for start in range(0, len(ids), batch_size):
            end = start + batch_size
            store._collection.upsert(
                ids=list(ids[start:end]),
                documents=list(texts[start:end]),
                metadatas=[dict(m) for m in metas[start:end]],
                embeddings=vectors[start:end].tolist(),
            )
        return len(stale)

    def delete_repo(self, repo: str) -> None:
        for kind in COLLECTIONS:
            ids = self._read(kind, where=build_where(repo), include=[])["ids"]
            if ids:
                self._store(kind).delete(ids=ids)

    # ---------------------------------------------------------------- reading

    def count(self, kind: str, repo: str) -> int:
        return len(self._read(kind, where=build_where(repo), include=[])["ids"])

    def search(
        self,
        kind: str,
        repo: str,
        query: str,
        n: int,
        filters: Mapping[str, str] | None = None,
    ) -> list[tuple[Document, float]]:
        """Nearest chunks as (document, cosine similarity), best first."""
        if n <= 0:
            return []
        vector = self.embeddings.embed_query(query)
        results = self._store(kind).similarity_search_by_vector_with_relevance_scores(
            vector, k=n, filter=build_where(repo, filters)
        )
        return [(doc, 1.0 - float(distance)) for doc, distance in results]

    def get_documents(self, kind: str, repo: str, ids: Sequence[str]) -> dict[str, Document]:
        """Chunks by id (ids missing from the collection are simply absent)."""
        if not ids:
            return {}
        found = self._read(
            kind, ids=list(ids), where=build_where(repo), include=["documents", "metadatas"]
        )
        return {
            chunk_id: Document(page_content=text, metadata=meta, id=chunk_id)
            for chunk_id, text, meta in zip(
                found["ids"], found["documents"], found["metadatas"], strict=True
            )
        }

    def repo_documents(
        self, kind: str, repo: str, filters: Mapping[str, str] | None = None
    ) -> list[Document]:
        """Text and metadata only, scoped to a repo; no embedding or model calls."""
        found = self._read(
            kind, where=build_where(repo, filters), include=["documents", "metadatas"]
        )
        docs = [
            Document(page_content=text, metadata=meta, id=cid)
            for cid, text, meta in zip(
                found["ids"], found["documents"], found["metadatas"], strict=True
            )
        ]
        return sorted(
            docs,
            key=lambda d: (
                str(d.metadata["path"]),
                int(d.metadata["start_line"]),
                str(d.metadata["chunk_id"]),
            ),
        )
