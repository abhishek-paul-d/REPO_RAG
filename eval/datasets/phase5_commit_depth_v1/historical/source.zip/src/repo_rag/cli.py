"""`repo-rag` command-line interface."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer
from git.exc import GitCommandError, GitError
from pydantic import SecretStr
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    TaskID,
    TextColumn,
    TimeElapsedColumn,
)
from rich.syntax import Syntax
from rich.table import Table

from repo_rag import __version__
from repo_rag.chunking.common import split_header
from repo_rag.config import Settings, get_settings
from repo_rag.history.index import index_history
from repo_rag.history.issue_linker import GitHubClient, GitHubLookupError
from repo_rag.ingest.github_client import clone, head_commit, parse_repo_url
from repo_rag.ingest.indexer import index_repo
from repo_rag.retrieval.bug_match import search_fixes
from repo_rag.retrieval.rerank import reranking_enabled
from repo_rag.retrieval.retrievers import HybridRetriever, SearchHit
from repo_rag.store.embeddings import get_embeddings
from repo_rag.store.manifest import Manifest
from repo_rag.store.transfer import TransferError, TransferResult, export_index, import_index
from repo_rag.store.vectorstore import COLLECTIONS, SEARCH_COLLECTIONS, VectorStore

app = typer.Typer(
    name="repo-rag",
    help="Code-aware RAG assistant for GitHub repositories.",
    no_args_is_help=True,
)
console = Console()

_PREVIEW_LINES = 12


def _not_implemented(feature: str, phase: int) -> None:
    console.print(f"[yellow]{feature} is not implemented yet (plan.md Phase {phase}).[/yellow]")
    raise typer.Exit(code=1)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"repo-rag {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool,
        typer.Option("--version", callback=_version_callback, is_eager=True, help="Show version."),
    ] = False,
) -> None:
    """Code-aware RAG assistant for GitHub repositories."""


@app.command()
def index(
    url: Annotated[
        str, typer.Argument(help="GitHub repository URL, e.g. https://github.com/psf/requests")
    ],
    history: Annotated[
        bool,
        typer.Option(
            "--history/--no-history", help="Fetch full commit history (blobless) or depth 1."
        ),
    ] = True,
    force: Annotated[
        bool, typer.Option("--force", help="Re-embed every chunk, even unchanged ones.")
    ] = False,
) -> None:
    """Clone a repository, chunk it, and build its search indexes."""
    settings = get_settings()
    try:
        with console.status(f"Cloning {url} ..."):
            ref, repo_dir = clone(url, settings, with_history=history)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc
    except (GitCommandError, FileExistsError) as exc:
        console.print(f"[red]Clone failed:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    commit_sha = head_commit(repo_dir)
    console.print(f"[green]{ref.slug}[/green] at {commit_sha[:12]} -> {repo_dir}")
    store = VectorStore(settings, get_embeddings(settings))

    with Progress(
        TextColumn("[progress.description]{task.description:<22}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        tasks: dict[str, TaskID] = {}

        def on_progress(stage: str, done: int, total: int) -> None:
            if stage not in tasks:
                tasks[stage] = progress.add_task(stage, total=total)
            progress.update(tasks[stage], completed=done, total=total)

        result = index_repo(
            ref.slug,
            repo_dir,
            commit_sha,
            store=store,
            settings=settings,
            force=force,
            on_progress=on_progress,
        )

    table = Table("Collection", "Files", "Chunks", "New", "Re-embedded", "Unchanged", "Removed")
    files_for = {"code": result.files["code"], "docs": result.files["doc"] + result.files["config"]}
    for kind in COLLECTIONS:
        s = result.sync[kind]
        table.add_row(
            kind,
            str(files_for[kind]),
            str(result.chunks[kind]),
            str(s.added),
            str(s.updated),
            str(s.unchanged + s.metadata_only),
            str(s.removed),
        )
    console.print(table)
    chunkers = ", ".join(f"{n} {name}" for name, n in sorted(result.chunkers.items()))
    console.print(f"Chunkers: {chunkers}. Done in {result.seconds:.1f}s.")


def _resolve_repo(settings: Settings, repo: str | None) -> str:
    entries = Manifest(settings.manifest_path).entries()
    if not entries:
        console.print("[red]Nothing is indexed yet.[/red] Run `repo-rag index <url>` first.")
        raise typer.Exit(code=1)
    if repo is None:
        if len(entries) > 1:
            names = ", ".join(sorted(entries))
            console.print(f"[red]Several repos are indexed; pick one with --repo:[/red] {names}")
            raise typer.Exit(code=2)
        repo = next(iter(entries))
    else:
        try:
            repo = parse_repo_url(repo).slug
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
            raise typer.Exit(code=2) from exc
    entry = entries.get(repo)
    if entry is None:
        console.print(f"[red]{repo} is not indexed.[/red] Indexed: {', '.join(sorted(entries))}")
        raise typer.Exit(code=1)
    if entry.embedding_id != settings.embedding_id:
        console.print(
            f"[red]{repo} was indexed with {entry.embedding_id}, but the current setting is "
            f"{settings.embedding_id}.[/red] Re-run `repo-rag index` to rebuild it."
        )
        raise typer.Exit(code=1)
    return repo


def _print_hit(rank: int, hit: SearchHit) -> None:
    meta = hit.document.metadata
    if meta.get("symbol_kind") == "commit":
        sha = str(meta["commit_sha"])
        console.print(
            f"{rank}. {sha[:12]}  https://github.com/{meta['repo']}/commit/{sha}", markup=False
        )
        console.print(hit.document.page_content, markup=False)
        return
    _, body = split_header(hit.document.page_content)
    lines = body.split("\n")
    shown = "\n".join(lines[:_PREVIEW_LINES])
    if len(lines) > _PREVIEW_LINES:
        shown += f"\n... ({len(lines) - _PREVIEW_LINES} more lines)"
    where = f"{meta['path']}:{meta['start_line']}-{meta['end_line']}"
    title = f"{rank}. {where}"
    if meta["symbol"]:
        title += f"  {meta['symbol']} ({meta['symbol_kind']})"
    if hit.expansion_mode is not None:
        detail = "related evidence (unscored)"
    elif hit.rerank_score is not None:
        detail = f"rerank {hit.rerank_score:.3f}"
    else:
        dense = f"#{hit.dense_rank}" if hit.dense_rank else "-"
        keyword = f"#{hit.bm25_rank}" if hit.bm25_rank else "-"
        detail = f"fused {hit.score:.4f}  dense {dense}  keyword {keyword}"
    lexer = str(meta["language"]) or "text"
    console.print(
        Panel(
            Syntax(shown, lexer, line_numbers=True, start_line=int(meta["start_line"])),
            title=title,
            subtitle=detail,
            title_align="left",
            subtitle_align="right",
        )
    )


@app.command()
def search(
    query: Annotated[str, typer.Argument(help="Search query.")],
    repo: Annotated[
        str | None,
        typer.Option("--repo", "-r", help="owner/name; optional if only one repo is indexed."),
    ] = None,
    k: Annotated[int, typer.Option("--k", "-k", min=1, help="Number of results.")] = 8,
    kind: Annotated[str, typer.Option("--kind", help="code, docs or commits.")] = "code",
    language: Annotated[str, typer.Option("--language", help="Only this language.")] = "",
    symbol_kind: Annotated[
        str, typer.Option("--symbol-kind", help="function, method, class, module or block.")
    ] = "",
    path: Annotated[str, typer.Option("--path", help="Only paths starting with this.")] = "",
    rerank: Annotated[
        bool,
        typer.Option("--rerank/--no-rerank", help="Cross-encoder rerank (needs a GPU)."),
    ] = False,
    rerank_depth: Annotated[
        int | None,
        typer.Option("--rerank-depth", min=1, help="Candidates to rerank; e.g. 20 or 50."),
    ] = None,
) -> None:
    """Search indexed chunks (no LLM): dense + keyword, fused."""
    if kind not in SEARCH_COLLECTIONS:
        console.print(f"[red]--kind must be one of: {', '.join(SEARCH_COLLECTIONS)}[/red]")
        raise typer.Exit(code=2)
    settings = get_settings()
    if rerank_depth is not None:
        settings = settings.model_copy(update={"rerank_candidate_depth": rerank_depth})
    if rerank and reranking_enabled(settings) and k > settings.rerank_candidate_depth:
        console.print("[red]--k cannot exceed the rerank candidate depth.[/red]")
        raise typer.Exit(code=2)
    slug = _resolve_repo(settings, repo)
    if kind == "commits":
        _require_history(settings, slug)
    if rerank and not reranking_enabled(settings):
        console.print("[yellow]Reranking skipped: reranker_mode=auto needs a CUDA GPU.[/yellow]")
    retriever = HybridRetriever(VectorStore(settings, get_embeddings(settings)), settings)
    with console.status("Searching ..."):
        hits = retriever.search(
            slug,
            query,
            kind=kind,
            k=k,
            filters={"language": language, "symbol_kind": symbol_kind, "path_prefix": path},
            rerank=rerank,
        )
    if not hits:
        console.print("[yellow]No results.[/yellow]")
        raise typer.Exit(code=1)
    for rank, hit in enumerate(hits, start=1):
        _print_hit(rank, hit)


def _slugs(repos: list[str] | None) -> list[str] | None:
    try:
        return [parse_repo_url(r).slug for r in repos] if repos else None
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc


def _print_transfer(result: TransferResult, verb: str) -> None:
    table = Table("Repo", "Code chunks", "Docs chunks", "Commits")
    for slug, counts in result.chunks.items():
        table.add_row(
            slug,
            str(counts.get("code", 0)),
            str(counts.get("docs", 0)),
            str(counts.get("commits", 0)),
        )
    console.print(table)
    console.print(f"{verb} {len(result.repos)} repo(s).")


@app.command("export-index")
def export_index_command(
    out: Annotated[Path, typer.Argument(help="Zip file to write.")],
    repo: Annotated[
        list[str] | None,
        typer.Option("--repo", "-r", help="owner/name; repeat for several. Default: all."),
    ] = None,
) -> None:
    """Pack indexed repos (text, metadata, vectors) into a zip to move to another machine."""
    settings = get_settings()
    store = VectorStore(settings, get_embeddings(settings))
    try:
        result = export_index(out, store=store, settings=settings, repos=_slugs(repo))
    except TransferError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    _print_transfer(result, f"Wrote {out} with")


@app.command("import-index")
def import_index_command(
    archive: Annotated[Path, typer.Argument(help="Zip made by `repo-rag export-index`.")],
    repo: Annotated[
        list[str] | None,
        typer.Option("--repo", "-r", help="owner/name; repeat for several. Default: all."),
    ] = None,
) -> None:
    """Merge an exported index into this machine's data. Nothing is re-embedded."""
    settings = get_settings()
    store = VectorStore(settings, get_embeddings(settings))
    try:
        with console.status("Importing ..."):
            result = import_index(archive, store=store, settings=settings, repos=_slugs(repo))
    except TransferError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    _print_transfer(result, "Imported")
    if result.removed:
        console.print(f"Replaced the old copies ({result.removed} stale chunks removed).")


@app.command()
def ask(
    question: Annotated[str, typer.Argument(help="Question about the indexed repository.")],
    repo: Annotated[str | None, typer.Option("--repo", "-r")] = None,
    bug: Annotated[
        bool, typer.Option("--bug", help="Find past fix commits for a bug report.")
    ] = False,
    rerank: Annotated[bool, typer.Option("--rerank", help="Opt-in GPU reranking.")] = False,
    k: Annotated[int, typer.Option("--k", "-k", min=1)] = 5,
) -> None:
    """Find cited past fixes with --bug. General question answering arrives in Phase 7."""
    if not bug:
        _not_implemented("General question answering (use ask --bug for commit evidence)", 7)
    if not question.strip():
        console.print("Bug report must not be blank.")
        raise typer.Exit(code=2)
    settings = get_settings()
    slug = _resolve_repo(settings, repo)
    _require_history(settings, slug)
    if rerank and not reranking_enabled(settings):
        console.print("[yellow]Reranking skipped: reranker_mode=auto needs a CUDA GPU.[/yellow]")
    if rerank and reranking_enabled(settings) and k > settings.rerank_candidate_depth:
        console.print("[red]--k cannot exceed the rerank candidate depth.[/red]")
        raise typer.Exit(code=2)
    retriever = HybridRetriever(VectorStore(settings, get_embeddings(settings)), settings)
    hits = search_fixes(retriever, slug, question, k=k, rerank=rerank)
    if not hits:
        console.print("No matching past fixes found.")
        raise typer.Exit(code=1)
    console.print("Retrieved past-fix candidates (relevance is not confirmation of the same bug):")
    for rank, hit in enumerate(hits, 1):
        _print_hit(rank, hit)


def _require_history(settings: Settings, slug: str) -> None:
    entry = Manifest(settings.manifest_path).get(slug)
    if entry is None or "commits" not in entry.chunks:
        console.print("Commit history is not indexed; run repo-rag index-history first.")
        raise typer.Exit(code=1)


@app.command("index-history")
def index_history_command(
    repo: Annotated[str, typer.Argument(help="GitHub owner/name.")],
    checkout: Annotated[Path, typer.Option("--checkout", exists=True, file_okay=False)],
    ref: Annotated[str, typer.Option("--ref", help="Pin a local commit or tag.")] = "HEAD",
    github: Annotated[
        bool, typer.Option("--github/--offline", help="Resolve cached/live issue links.")
    ] = False,
) -> None:
    """Index a local clone's bounded history; --github enables read-only GitHub lookups."""
    settings = get_settings()
    try:
        slug = parse_repo_url(repo).slug
        if github and not settings.github_token:
            raise GitHubLookupError("Set GITHUB_TOKEN in .env before live GitHub lookups")
        result = index_history(
            slug,
            checkout,
            settings,
            VectorStore(settings, get_embeddings(settings)),
            ref=ref,
            client=GitHubClient(settings) if github else None,
        )
    except (ValueError, GitHubLookupError, GitError) as exc:
        console.print(str(exc), markup=False)
        raise typer.Exit(code=1) from exc
    console.print(
        f"Indexed {result.commits} commits; {result.fix_candidates} fix candidates. "
        f"Links: {result.direct_links} direct, {result.via_pr_links} via PR. "
        f"Embedded {result.sync.embedded}; unchanged {result.sync.unchanged}."
    )


@app.command("config")
def show_config() -> None:
    """Show the effective configuration (secrets masked)."""
    settings = get_settings()
    table = Table("Setting", "Value")
    for name, value in settings.model_dump().items():
        if isinstance(value, SecretStr):
            shown = "set" if value.get_secret_value() else "empty"
        elif value is None:
            shown = "-"
        else:
            shown = str(value)
        table.add_row(name, shown)
    console.print(table)


if __name__ == "__main__":
    app()
