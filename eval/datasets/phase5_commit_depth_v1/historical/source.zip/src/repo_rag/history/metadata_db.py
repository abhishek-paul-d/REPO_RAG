"""Phase 5 history/link tables, isolated by repository.

Query handles use SQLite mode=ro; only typed, parameterized methods are exposed. The
larger PR/review/identity schema remains Phase 5b. New snapshots redact email-like strings
throughout commit/issue payloads. Reads also redact legacy payloads; reindex to replace old
database contents. Frozen evaluation source records deliberately retain historical bytes.
"""

from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any

from repo_rag.history.commit_indexer import CommitRecord, FileChange, Hunk
from repo_rag.history.issue_linker import Issue, IssueLink

_SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS history_commits (
 repo TEXT NOT NULL, sha TEXT NOT NULL, author_name TEXT NOT NULL,
 committer_name TEXT NOT NULL, author_date TEXT NOT NULL, commit_date TEXT NOT NULL,
 message TEXT NOT NULL, is_fix INTEGER NOT NULL, record_json TEXT NOT NULL,
 PRIMARY KEY(repo, sha));
CREATE TABLE IF NOT EXISTS history_files (
 repo TEXT NOT NULL, sha TEXT NOT NULL, path TEXT NOT NULL, old_path TEXT NOT NULL,
 additions INTEGER NOT NULL, deletions INTEGER NOT NULL,
 PRIMARY KEY(repo,sha,path),
 FOREIGN KEY(repo,sha) REFERENCES history_commits(repo,sha) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS history_symbols (
 repo TEXT NOT NULL, sha TEXT NOT NULL, path TEXT NOT NULL, symbol TEXT NOT NULL,
 PRIMARY KEY(repo,sha,path,symbol),
 FOREIGN KEY(repo,sha) REFERENCES history_commits(repo,sha) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS history_issues (
 repo TEXT NOT NULL, number INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
 state TEXT NOT NULL, url TEXT NOT NULL, PRIMARY KEY(repo,number));
CREATE TABLE IF NOT EXISTS issue_links (
 repo TEXT NOT NULL, commit_sha TEXT NOT NULL, issue_repo TEXT NOT NULL,
 issue_number INTEGER NOT NULL, pr_number INTEGER NOT NULL DEFAULT 0,
 link_type TEXT NOT NULL CHECK(link_type IN ('direct','via_pr')),
 PRIMARY KEY(repo,commit_sha,issue_repo,issue_number,pr_number,link_type),
 FOREIGN KEY(repo,commit_sha) REFERENCES history_commits(repo,sha) ON DELETE CASCADE,
 FOREIGN KEY(issue_repo,issue_number) REFERENCES history_issues(repo,number));
"""

_EMAIL = re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}")


def _safe_payload(value: dict) -> dict:
    """Redact nested textual fields, including trailers and patches, before persistence/output."""

    def redact(item: Any) -> Any:
        if isinstance(item, str):
            return _EMAIL.sub("<email omitted>", item)
        if isinstance(item, dict):
            return {key: redact(text) for key, text in item.items()}
        if isinstance(item, (tuple, list)):
            return [redact(text) for text in item]
        return item

    return {key: redact(item) for key, item in value.items()}


def record_from_dict(data: dict) -> CommitRecord:
    data = dict(data)
    files = []
    for item in data.pop("files"):
        item = dict(item)
        item["hunks"] = tuple(Hunk(**h) for h in item["hunks"])
        item["symbols"] = tuple(item["symbols"])
        files.append(FileChange(**item))
    return CommitRecord(**data, files=tuple(files))


class MetadataDB:
    def __init__(self, path: Path, *, readonly: bool = True) -> None:
        self.path = path
        self.readonly = readonly
        if readonly:
            self.connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            self.connection = sqlite3.connect(path)
            self.connection.executescript(_SCHEMA)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA foreign_keys=ON")

    def __enter__(self) -> MetadataDB:
        return self

    def __exit__(self, *_: object) -> None:
        self.connection.close()

    def sync_history(
        self, repo: str, records: list[CommitRecord], links: list[IssueLink], issues: list[Issue]
    ) -> None:
        """Atomically replace one bounded repo snapshot; preserve every other repository."""
        if self.readonly:
            raise PermissionError("MetadataDB is open read-only")
        if any(r.repo != repo for r in records) or any(link.repo != repo for link in links):
            raise ValueError("cross-repository history snapshot")
        linked = {link.commit_sha for link in links}
        records = [record_from_dict(_safe_payload(asdict(r))) for r in records]
        issues = [Issue(**_safe_payload(asdict(i))) for i in issues]
        with self.connection:
            self.connection.execute("DELETE FROM history_commits WHERE repo=?", (repo,))
            self.connection.executemany(
                "INSERT INTO history_commits VALUES(?,?,?,?,?,?,?,?,?)",
                [
                    (
                        repo,
                        r.sha,
                        r.author_name,
                        r.committer_name,
                        r.author_date,
                        r.commit_date,
                        r.message,
                        int(r.is_fix or r.sha in linked),
                        json.dumps(asdict(replace(r, is_fix=r.is_fix or r.sha in linked))),
                    )
                    for r in records
                ],
            )
            self.connection.executemany(
                "INSERT INTO history_files VALUES(?,?,?,?,?,?)",
                [
                    (repo, r.sha, f.path, f.old_path, f.additions, f.deletions)
                    for r in records
                    for f in r.files
                ],
            )
            self.connection.executemany(
                "INSERT INTO history_symbols VALUES(?,?,?,?)",
                [
                    (repo, r.sha, f.path, symbol)
                    for r in records
                    for f in r.files
                    for symbol in f.symbols
                ],
            )
            self.connection.executemany(
                "INSERT INTO history_issues VALUES(?,?,?,?,?,?) ON CONFLICT(repo,number) "
                "DO UPDATE SET title=excluded.title,body=excluded.body,"
                "state=excluded.state,url=excluded.url",
                [(i.repo, i.number, i.title, i.body, i.state, i.url) for i in issues],
            )
            self.connection.executemany(
                "INSERT INTO issue_links VALUES(?,?,?,?,?,?)",
                [
                    (
                        link.repo,
                        link.commit_sha,
                        link.issue_repo,
                        link.issue_number,
                        link.pr_number or 0,
                        link.link_type,
                    )
                    for link in links
                ],
            )

    def get_commit(self, repo: str, sha: str) -> CommitRecord | None:
        row = self.connection.execute(
            "SELECT record_json FROM history_commits WHERE repo=? AND sha=?", (repo, sha)
        ).fetchone()
        return record_from_dict(_safe_payload(json.loads(row[0]))) if row else None

    def query_commits(
        self, repo: str, *, is_fix: bool | None = None, limit: int = 50
    ) -> list[CommitRecord]:
        if limit < 1:
            raise ValueError("limit must be positive")
        rows = self.connection.execute(
            "SELECT record_json FROM history_commits WHERE repo=? AND (? IS NULL OR is_fix=?) "
            "ORDER BY commit_date DESC,sha LIMIT ?",
            (repo, is_fix, is_fix, limit),
        )
        return [record_from_dict(_safe_payload(json.loads(row[0]))) for row in rows]

    def links(self, repo: str, *, sha: str | None = None) -> list[IssueLink]:
        rows = self.connection.execute(
            "SELECT * FROM issue_links WHERE repo=? AND (? IS NULL OR commit_sha=?) "
            "ORDER BY commit_sha,issue_repo,issue_number,link_type,pr_number",
            (repo, sha, sha),
        )
        return [
            IssueLink(
                row["repo"],
                row["commit_sha"],
                row["issue_repo"],
                row["issue_number"],
                row["link_type"],
                row["pr_number"] or None,
            )
            for row in rows
        ]

    def get_issue(self, repo: str, number: int) -> Issue | None:
        row = self.connection.execute(
            "SELECT * FROM history_issues WHERE repo=? AND number=?", (repo, number)
        ).fetchone()
        return Issue(**_safe_payload(dict(row))) if row else None
