"""FastAPI server."""
