"""Streamlit chat UI."""
